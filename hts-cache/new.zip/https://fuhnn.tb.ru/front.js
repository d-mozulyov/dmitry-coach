
<html lang='ru'>
    <head>
        <meta charset='utf-8' />
        <meta
            name='viewport'
            content='user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi'
        />
        <title>
            Страница не найдена
        </title>
        <link href='https://s.tb.ru/info/styles.css' rel='stylesheet' />

        <script>
            const url = location.pathname; const lowercasedUrl = url.toLowerCase(); if (lowercasedUrl !== url) {
            location.href = location.href.replace(location.pathname, lowercasedUrl); }
        </script>

    </head>

    <body class='body-info'>
        <div class='info-page'>
            <div class='info-page__content'>
                <img class='info-page__image' src='https://s.tb.ru/info/space.svg' alt='info-page-image' />
                <h2 class='info-page__title'>
                    Такой страницы не существует
                </h2>
                    <p class='info-page__text'>
                        Мы не смогли найти такую страницу, но, возможно, вам подойдет это:
                    </p>
                    <ul class='info-page__links'>
                            <li class='info-page__links-item'>
                                <a class='info-page__link' href='/agile'>
                                    Agile | Дмитрий Мозулёв
                                </a>
                            </li>
                            <li class='info-page__links-item'>
                                <a class='info-page__link' href='/'>
                                    Коучинг | Дмитрий Мозулёв
                                </a>
                            </li>
                    </ul>
            </div>
                <div class='footer-text'>
                    Ошибка 404
                </div>
        </div>
    </body>
</html>